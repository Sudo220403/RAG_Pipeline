import subprocess
import shutil

def generate_with_ollama(prompt: str) -> str:
    # Step 1: Check if ollama is installed
    if not shutil.which("ollama"):
        raise RuntimeError("Ollama CLI not found. Please install Ollama and add it to your system PATH.")

    # Step 2: Build the command
    command = ["ollama", "run", "llama3", prompt]

    try:
        # Step 3: Run the command
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"❌ Error during Ollama call:\n{e.stderr.strip()}"
    except Exception as e:
        return f"❌ Unexpected error:\n{str(e)}"
