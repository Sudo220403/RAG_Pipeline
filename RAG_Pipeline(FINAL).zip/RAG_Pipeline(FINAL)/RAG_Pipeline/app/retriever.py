import faiss
import numpy as np

class VectorStore:
    def __init__(self):
        self.index = None
        self.texts = []

    def build_index(self, embeddings, texts):
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(embeddings)
        self.texts = texts

    def retrieve(self, query_embedding, top_k=3):
        D, I = self.index.search(query_embedding, top_k)
        return [self.texts[i] for i in I[0]]
