import os
from docx import Document
import PyPDF2

def load_text_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

def load_docx_file(filepath):
    doc = Document(filepath)
    return "\n".join([p.text for p in doc.paragraphs])

def load_pdf_file(filepath):
    with open(filepath, 'rb') as f:
        reader = PyPDF2.PdfReader(f)
        return "\n".join([page.extract_text() for page in reader.pages])

def load_document(filepath):
    ext = os.path.splitext(filepath)[-1].lower()
    if ext == '.txt':
        return load_text_file(filepath)
    elif ext == '.docx':
        return load_docx_file(filepath)
    elif ext == '.pdf':
        return load_pdf_file(filepath)
    else:
        raise ValueError(f"Unsupported file type: {ext}")
