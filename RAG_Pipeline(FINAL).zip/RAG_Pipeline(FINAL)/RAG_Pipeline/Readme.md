#RAG Pipeline: Document Question Answering API

This project implements a **Retrieval-Augmented Generation (RAG)** pipeline using **FastAPI**, allowing users to upload documents and ask context-based questions. The system semantically retrieves relevant text chunks and generates precise answers using a local LLM via **Ollama**.


##Features

Upload documents (`.pdf`, `.txt`, `.docx`)
Chunking & embedding using `SentenceTransformer`
Semantic search with FAISS
LLM-based answer generation using **Ollama**
FastAPI backend with interactive Swagger UI (`/docs`)