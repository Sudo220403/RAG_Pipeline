from fastapi import FastAPI, UploadFile, File
from app.document_loader import load_document
from app.chunker import chunk_text
from app.embedder import get_embeddings
from app.retriever import VectorStore
from app.generator import generate_with_ollama
from pydantic import BaseModel
import numpy as np

app = FastAPI()
store = VectorStore()

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    content = await file.read()
    with open(file.filename, "wb") as f:
        f.write(content)
    text = load_document(file.filename)
    chunks = chunk_text(text)
    embeddings = get_embeddings(chunks)
    store.build_index(np.array(embeddings), chunks)
    return {"status": "Document processed and indexed"}

# ✅ This Pydantic model receives a JSON question payload
class QueryRequest(BaseModel):
    question: str

# ✅ This now uses your actual vector store + generator logic
@app.post("/ask")
async def ask_question(request: QueryRequest):
    q_embedding = get_embeddings([request.question])
    context_chunks = store.retrieve(np.array(q_embedding))
    context = "\n".join(context_chunks)
    prompt = f"Answer this based on the context:\n{context}\n\nQuestion: {request.question}"
    response = generate_with_ollama(prompt)
    return {"answer": response}
